#include <stdlib.h>
#include <limits.h>

#include "mapa.h"

struct smapa {
  int chave;
  int dado;
  short int bf;
  struct smapa* esq;
  struct smapa *dir;
};

static Mapa *cria_no (int c, int novodado) {
  Mapa *nn = (Mapa *)malloc(sizeof(Mapa));
  if (nn!=NULL) {
    nn->esq = nn->dir = NULL;
    nn->chave =c;
    nn->dado = novodado;
    nn->bf = 0;
  }
  return nn;
}

Mapa* cria (void) {
  return NULL;
}

Mapa* insere (Mapa* m, int chave, int novodado, int *flag) {
	if (m == NULL) {
		m = (Mapa*) malloc (sizeof(Mapa))		;
		m->esq = m->dir = NULL;
		m->chave = chave;
		m->dado = novodado;
		m->fb = 0;
		*flag = 1;
	}
	else if (m->chave > chave) {
		m->esq = insere(m->esq, chave, novodado, flag);
		
		if (*flag) {
			if (m->fb == 0) {
				m->fb = -1;
			} else if (m->fb = 1) {
				m->fb = 0;
				*flag = 0;
			} else {
				ajusta_esq(m);
				*flag = 0;
			}
		}
	}
	else if (m->chave < chave) {
		m->dir = insere(m->dir, chave, novodado, flag);
		
		if (*flag) {
			if (m->fb == 0) {
				m->fb = 1;
			} else if (m->fb = -1) {
				m->fb = 0;
			} else {
				ajusta_dir(m);
			}
		}	
	}

	return m;
}


Mapa* ajusta_dir(Mapa* m) {
	Mapa *t;
	if (m->dir == 1) {
		t = rotacao_esq(m);
	} else if (m->esq == 1) {
		m->dir = rotacao_dir(m->dir);
		t = rotacao_esq(m);
	}
	return t;
}

Mapa* ajusta_esq(Mapa* m) {
	Mapa* t;
	if (m->esq.bf == -1) {
		t= rotacao_dir(m);
	} else if (m->esq.bf == 1) {
		m->esq = rotacao_esq(m->esq);
		t = rotacao_dir(m);
	}
	return t;
}

Mapa* rotacao_dir(Mapa* m) {
	Mapa*t = m->esq, *r = t->dir;
	t->dir = m;
	m->esq = r;
	t->fb = m->fb = 0;
	return t;
}


Mapa* rotacao_esquerda(Mapa* m) {
	Mapa*t = m->esq, *r = t->dir;
	t->esq = m;
	m->dir = r;
	t->fb = m->fb = 0;
	return t;
}



int busca (Mapa *m, int chave) {
	while(m != NULL) {
		if (chave < m->chave) {
			m = m->esq;
		} 
		else if (chave > m->chave) {
			m = m->dir;
		} 
		else {
			return m->dado;
		}
	}

	return INT_MAX;
}

Mapa* remove (Mapa *m, int chave){
  return m;
}

void destroi (Mapa *m){
}




void debug_mostra_mapa(Mapa* m) {
	if(m != NULL) {
		printf("%d ", m->chave);
	        imprimeMapa(m->dir);
	        imprimeMapa(m->esq);
	}
}


